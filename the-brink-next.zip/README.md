# The Brink — Next.js

This is a Next.js (App Router) version of the Brink Newsflash UI.

## Local dev

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Deploy (easiest)

Deploy on Vercel:
1. Push this repo to GitHub
2. Go to Vercel, "Add New Project" → Import your GitHub repo
3. Click Deploy

## Notes
- Live RSS mode uses a public CORS proxy (`allorigins.win`). Some feeds may block it.
- For production, replace the proxy with a server-side route (Next.js Route Handler) that fetches RSS.

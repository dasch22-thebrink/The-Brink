'use client';

import React, { useEffect, useMemo, useRef, useState } from 'react';

/**
 * The Brink — Newsflash (Drudge-like)
 * Single-file React preview.
 *
 * Notes:
 *  - This page is a "client component" because it uses hooks and DOMParser/fetch.
 *  - Live RSS uses a public proxy. Some publishers may block it.
 */

function minutesAgoISO(mins: number) {
  return new Date(Date.now() - mins * 60 * 1000).toISOString();
}

function safeSplitLines(text: string) {
  const t = String(text || '').replaceAll('\r\n', '\n').replaceAll('\r', '\n');
  return t.split('\n');
}

function escapeRegExpNoRegex(str: string) {
  const s = String(str || '');
  const special = new Set(['\\', '^', '$', '.', '*', '+', '?', '(', ')', '[', ']', '{', '}', '|']);
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    out += special.has(ch) ? `\\${ch}` : ch;
  }
  return out;
}

type BrinkItem = {
  id: string;
  section: 'TOP' | 'FLASH' | 'CENTER' | 'RELEASES' | 'RESEARCH' | 'BUSINESS' | 'POLICY';
  title: string;
  source: string;
  url: string;
  ts: string;
  image?: string;
  flags?: {
    breaking?: boolean;
    release?: boolean;
    research?: boolean;
    business?: boolean;
    policy?: boolean;
    tools?: boolean;
    analysis?: boolean;
  };
};

function generateCuratedNewsflashMock(): { items: BrinkItem[] } {
  const items: BrinkItem[] = [
    {
      id: 'lead',
      section: 'TOP',
      title: 'BREAKING: NewModelX ships — benchmarks surge, ecosystem reacts',
      source: 'Company Blog',
      url: '#',
      ts: minutesAgoISO(6),
      flags: { breaking: true, release: true }
    },
    {
      id: 'sub1',
      section: 'TOP',
      title: 'Researchers replicate early results; claim “step change” on open evals',
      source: 'arXiv — cs.AI',
      url: '#',
      ts: minutesAgoISO(12),
      flags: { breaking: true, research: true }
    },
    {
      id: 'sub2',
      section: 'TOP',
      title: 'Competitors respond; new pricing + safety notes published',
      source: 'Reuters',
      url: '#',
      ts: minutesAgoISO(18),
      flags: { business: true }
    },

    { id: 'b1', section: 'FLASH', title: 'Leak: NewModelX-mini spotted in API docs', source: 'X — AI', url: '#', ts: minutesAgoISO(22), flags: { breaking: true } },
    { id: 'b2', section: 'FLASH', title: 'Tool builders push same-day integrations', source: 'AI Forum', url: '#', ts: minutesAgoISO(26), flags: { tools: true } },

    { id: 'c1', section: 'CENTER', title: 'What changed: why NewModelX is breaking (3 key reasons)', source: 'DeepAnalysis', url: '#', ts: minutesAgoISO(9), flags: { analysis: true } },
    { id: 'c2', section: 'CENTER', title: 'Market reaction: infra demand spikes after release', source: 'Business Insider', url: '#', ts: minutesAgoISO(34), flags: { business: true } },

    { id: 'r1', section: 'RELEASES', title: 'NewModelX release notes: context window, safety filters, pricing', source: 'Company Blog', url: '#', ts: minutesAgoISO(6), flags: { release: true } },
    { id: 'r2', section: 'RELEASES', title: 'SDK update: streaming + tool-calling improvements', source: 'Docs', url: '#', ts: minutesAgoISO(15), flags: { release: true, tools: true } },

    { id: 'p1', section: 'RESEARCH', title: 'Paper: Edge inference at scale — latency drops with new kernel', source: 'arXiv — cs.LG', url: '#', ts: minutesAgoISO(62), flags: { research: true } },
    { id: 'm1', section: 'BUSINESS', title: 'Funding: AI infrastructure round closes amid demand spike', source: 'The Information', url: '#', ts: minutesAgoISO(110), flags: { business: true } },
    { id: 'k1', section: 'POLICY', title: 'Draft guidance: model release transparency requirements', source: 'Reg Brief', url: '#', ts: minutesAgoISO(210), flags: { policy: true } }
  ];

  const flashTitles = [
    'Benchmark: NewModelX passes key safety regressions',
    'Rumor: on-device variant teased for mobile chips',
    'Enterprise: early access waitlist opens',
    'Open-source community begins fine-tune sprint',
    'GPU spot prices jump amid inference demand',
    'New eval suite published (hallucination + tool use)',
    'Major lab updates alignment policy',
    'NewModelX hits top of public leaderboard',
    'Compiler team ships latency patch',
    'Agent framework adds NewModelX connector',
    'Red-team report: improved jailbreak resistance',
    'Developer SDK adds structured output helpers',
    'Realtime voice demo goes viral',
    'New safety doc: deployment guidelines',
    'Competitor announces “coming soon” response',
    'API rate limits adjusted after launch',
    'Inference cost curve shows step-change',
    'Model card updated with new capabilities',
    'Partnership: major cloud rolls out integration',
    'Regulators request clarification on release',
    'Rumor: new multimodal feature incoming',
    'Tooling: IDE extension updates overnight',
    'Community: prompt library hits #1 on GitHub',
    'Breaking: outage resolved — service restored',
    'Breaking: new checkpoint pushed',
    'Breaking: vulnerability patched',
    'Breaking: press conference scheduled',
    'Leak: new pricing tier mentioned in docs',
    'Just in: new safety benchmark published',
    'Developing: partner integrations rolling out'
  ];

  for (let i = 0; i < flashTitles.length; i++) {
    items.push({
      id: `flash-${i + 1}`,
      section: 'FLASH',
      title: flashTitles[i],
      source: i % 3 === 0 ? 'X — AI' : i % 3 === 1 ? 'AI Forum' : 'DevWatch',
      url: '#',
      ts: minutesAgoISO(30 + i * 3),
      flags: {
        breaking:
          flashTitles[i].toLowerCase().includes('breaking') ||
          flashTitles[i].toLowerCase().includes('leak') ||
          flashTitles[i].toLowerCase().includes('just in')
      }
    });
  }

  for (let i = 0; i < 12; i++) {
    items.push({
      id: `center-${i + 3}`,
      section: 'CENTER',
      title: `Roundup: ${i % 2 === 0 ? 'tools' : 'research'} moves you missed (${i + 1})`,
      source: i % 2 === 0 ? 'The Brink' : 'Lab Notes',
      url: '#',
      ts: minutesAgoISO(45 + i * 12),
      flags: { analysis: true }
    });
  }

  return { items };
}

function firstImageFromHtml(html: string) {
  try {
    const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
    const img = doc.querySelector('img');
    const src = img?.getAttribute('src') || '';
    return src && src.startsWith('http') ? src : '';
  } catch {
    return '';
  }
}

function pickFeedImage(node: Element, descHtml: string) {
  try {
    const enc = node.querySelector('enclosure');
    const encUrl = enc?.getAttribute('url') || '';
    const encType = (enc?.getAttribute('type') || '').toLowerCase();
    if (encUrl && encUrl.startsWith('http') && (!encType || encType.includes('image'))) return encUrl;

    const mt = node.querySelector('media\\:thumbnail');
    const mtUrl = mt?.getAttribute('url') || '';
    if (mtUrl && mtUrl.startsWith('http')) return mtUrl;

    const mc = node.querySelector('media\\:content');
    const mcUrl = mc?.getAttribute('url') || '';
    const mcType = (mc?.getAttribute('type') || '').toLowerCase();
    if (mcUrl && mcUrl.startsWith('http') && (!mcType || mcType.includes('image'))) return mcUrl;

    const itemImgUrl = node.querySelector('image > url')?.textContent?.trim() || '';
    if (itemImgUrl && itemImgUrl.startsWith('http')) return itemImgUrl;

    const fromDesc = firstImageFromHtml(descHtml);
    if (fromDesc) return fromDesc;
  } catch {
    // ignore
  }
  return '';
}

function LinkItem({ item, strong = false, showImages = true }: { item: BrinkItem; strong?: boolean; showImages?: boolean }) {
  const isBreaking = !!item.flags?.breaking;
  const hasImg = showImages && !!item.image;

  const img = hasImg ? (
    <img
      src={item.image}
      alt=""
      loading="lazy"
      referrerPolicy="no-referrer"
      style={{ width: 44, height: 44, objectFit: 'cover', border: '1px solid #ddd', background: '#f3f3f3', flex: '0 0 auto' }}
      onError={(e) => {
        try {
          (e.currentTarget as HTMLImageElement).style.display = 'none';
        } catch {}
      }}
    />
  ) : null;

  return (
    <div style={{ marginBottom: 6, lineHeight: 1.25, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
      {img}
      <div style={{ minWidth: 0 }}>
        {isBreaking ? (
          <span style={{ display: 'inline-block', background: '#b30000', color: '#fff', padding: '1px 6px', marginRight: 6, fontSize: 10, fontWeight: 900 }}>
            BREAKING
          </span>
        ) : null}

        <a href={item.url} target="_blank" rel="noreferrer" style={{ color: '#0b3d91', textDecoration: 'none', fontWeight: strong ? 800 : 700, wordBreak: 'break-word' }}>
          {item.title}
        </a>
        <span style={{ color: '#444', fontSize: 12 }}> — {item.source}</span>
      </div>
    </div>
  );
}

function parseStooqCSV(text: string): { symbol: string; close: number }[] {
  const lines = safeSplitLines(text).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return [];

  const header = lines[0].split(',').map((s) => s.trim().toLowerCase());
  const idx = (name: string) => header.indexOf(name);
  const symI = idx('symbol');
  const closeI = idx('close');
  if (symI === -1 || closeI === -1) return [];

  const out: { symbol: string; close: number }[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',');
    if (cols.length <= closeI) continue;
    const symbol = String(cols[symI] || '').trim();
    const close = Number(cols[closeI]);
    if (!symbol || !Number.isFinite(close)) continue;
    out.push({ symbol, close });
  }
  return out;
}

function stripStooqSuffix(sym: string) {
  const upper = String(sym || '').trim().toUpperCase();
  return upper.endsWith('.US') ? upper.slice(0, -3) : upper;
}

type Quote = { symbol: string; price: number | null; change: number | null };

function StockTicker({
  enabled,
  onToggle,
  symbols,
  fetchViaProxy,
  minimal = false
}: {
  enabled: boolean;
  onToggle: () => void;
  symbols: string[];
  fetchViaProxy: (url: string) => Promise<string>;
  minimal?: boolean;
}) {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const tapeRef = useRef<HTMLDivElement | null>(null);
  const [duration, setDuration] = useState<number>(26);
  const demoFallback = useMemo<Quote[]>(
    () => [
      { symbol: 'NVDA', price: 892.15, change: 12.44 },
      { symbol: 'MSFT', price: 421.33, change: -1.28 },
      { symbol: 'GOOGL', price: 168.92, change: 2.11 },
      { symbol: 'META', price: 512.4, change: 6.87 },
      { symbol: 'AMD', price: 176.03, change: -0.94 },
      { symbol: 'PLTR', price: 24.17, change: 0.63 }
    ],
    []
  );
  const demoBy = useMemo(() => new Map(demoFallback.map((d) => [d.symbol, d])), [demoFallback]);
  const display = useMemo<Quote[]>(() => {
    const quoteBy = new Map((quotes || []).map((q) => [q.symbol, q]));
    return (symbols || [])
      .map((s) => String(s || '').trim().toUpperCase())
      .filter(Boolean)
      .map((sym) => quoteBy.get(sym) || demoBy.get(sym) || { symbol: sym, price: null, change: null });
  }, [quotes, symbols, demoBy]);

  async function refreshQuotes() {
    if (!enabled) return;
    try {
      const stooqSymbols = (symbols || []).map((s) => String(s || '').trim().toUpperCase()).filter(Boolean).map((s) => `${s}.US`).join(',');
      if (!stooqSymbols) return;
      const url = `https://stooq.com/q/l/?s=${encodeURIComponent(stooqSymbols)}&f=sd2t2ohlcv&h&e=csv`;
      const csv = await fetchViaProxy(url);
      const parsed = parseStooqCSV(csv);
      const bySymbol = new Map(parsed.map((p) => [stripStooqSuffix(p.symbol), p.close]));
      setQuotes((prev) => {
        const prevBy = new Map(prev.map((q) => [q.symbol, q.price]));
        const next = (symbols || [])
          .map((sym) => {
            const s = String(sym || '').trim().toUpperCase();
            if (!s) return null;
            const price = bySymbol.get(s);
            if (!Number.isFinite(price)) return null;
            const prevPrice = prevBy.get(s);
            const change = Number.isFinite(Number(prevPrice)) ? Number(price) - Number(prevPrice) : 0;
            return { symbol: s, price: Number(price), change } as Quote;
          })
          .filter(Boolean) as Quote[];
        return next.length ? next : prev;
      });
    } catch {}
  }

  useEffect(() => {
    if (!enabled) return;
    refreshQuotes();
    const t = setInterval(refreshQuotes, 60 * 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, (symbols || []).join(',')]);

  useEffect(() => {
    if (!enabled) return;
    const pxPerSecond = 34;
    const recalc = () => {
      const el = tapeRef.current;
      if (!el) return;
      const total = el.scrollWidth || 0;
      if (!total) return;
      const oneCopy = Math.max(1, total / 2);
      const next = Math.max(18, oneCopy / pxPerSecond);
      if (Number.isFinite(next)) setDuration(next);
    };
    recalc();
    window.addEventListener('resize', recalc);
    return () => window.removeEventListener('resize', recalc);
  }, [enabled, display.length]);

  if (!enabled) return null;

  return (
    <div style={{ width: '100%', marginTop: 6 }}>
      <div style={{ width: '100%', overflow: 'hidden', borderTop: '1px solid #e6e6e6', borderBottom: '1px solid #e6e6e6', background: '#f2f2f2', position: 'relative', height: 26 }}>
        <div
          ref={tapeRef}
          style={{
            display: 'flex',
            flexWrap: 'nowrap',
            alignItems: 'center',
            whiteSpace: 'nowrap',
            width: 'max-content',
            minWidth: '200%',
            animation: `tickerMarquee ${duration}s linear infinite`,
            willChange: 'transform'
          }}
        >
          {display.map((q, i) => (
            <span key={`a-${q.symbol}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', marginRight: 12, fontSize: 11, lineHeight: '26px', color: '#666' }}>
              <span style={{ fontWeight: 900 }}>{q.symbol}</span>
              {q.price != null ? <span style={{ fontWeight: 700, marginLeft: 6 }}>{Number(q.price).toFixed(2)}</span> : null}
            </span>
          ))}
          {display.map((q, i) => (
            <span key={`b-${q.symbol}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', marginRight: 12, fontSize: 11, lineHeight: '26px', color: '#666' }}>
              <span style={{ fontWeight: 900 }}>{q.symbol}</span>
              {q.price != null ? <span style={{ fontWeight: 700, marginLeft: 6 }}>{Number(q.price).toFixed(2)}</span> : null}
            </span>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes tickerMarquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}

function parseWatchlist(str: string) {
  return String(str || '').split(',').map((s) => s.trim()).filter(Boolean);
}

function tokenizeLower(text: string) {
  const s = String(text || '').toLowerCase();
  const out: string[] = [];
  let cur = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    const isWord = (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9');
    if (isWord) cur += ch;
    else if (cur) { out.push(cur); cur = ''; }
  }
  if (cur) out.push(cur);
  return out;
}

type FeedMeta = { name: string; url: string; category: string; aiOnly: boolean };

function parseFeed(xmlText: string, feedMeta: FeedMeta) {
  const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
  const rssItems = Array.from(doc.querySelectorAll('item'));
  if (rssItems.length) {
    return rssItems.map((node, idx) => {
      const title = node.querySelector('title')?.textContent?.trim() || '';
      const link = node.querySelector('link')?.textContent?.trim() || '';
      const pub = node.querySelector('pubDate')?.textContent?.trim() || '';
      const desc = node.querySelector('description')?.textContent?.trim() || '';
      return {
        id: `${feedMeta.name}-rss-${idx}-${link || title}`,
        title,
        url: link || '#',
        source: feedMeta.name,
        ts: pub ? new Date(pub).toISOString() : new Date().toISOString(),
        summary: desc,
        image: pickFeedImage(node, desc),
        _category: feedMeta.category,
        _aiOnly: feedMeta.aiOnly
      };
    });
  }
  return [];
}

export default function TheBrinkNewsflash() {
  // NOTE: This file is intentionally slimmed (ticker + layout) to keep the Next starter small.
  // If you want, we can paste the full canvas version here—just say so.
  const [mode, setMode] = useState<'mock' | 'rss'>('mock');
  const [viewMode, setViewMode] = useState<'web' | 'app'>('web');
  const [items, setItems] = useState<BrinkItem[]>([]);
  const [showTicker, setShowTicker] = useState(true);

  const AI_STOCKS = useMemo(() => ['NVDA', 'MSFT', 'GOOGL', 'META', 'AMZN', 'AAPL', 'TSLA', 'AMD', 'INTC'], []);
  const [tickerSymbols, setTickerSymbols] = useState<string[]>(AI_STOCKS);

  async function fetchViaProxy(url: string) {
    const proxied = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
    const res = await fetch(proxied);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  }

  useEffect(() => {
    const m = generateCuratedNewsflashMock();
    setItems(m.items);
  }, [mode]);

  const pageStyle: React.CSSProperties = { overflowX: 'hidden', background: '#fff', color: '#111', minHeight: '100vh', fontFamily: 'Arial, Helvetica, sans-serif', width: '100%' };
  const wrapStyle: React.CSSProperties = { maxWidth: 1020, width: '100%', margin: '0 auto', padding: '14px 12px 40px', boxSizing: 'border-box' };

  return (
    <div style={pageStyle}>
      <div style={wrapStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
          <div>
            <div style={{ fontSize: 30, fontWeight: 900 }}>THE BRINK</div>
            <div style={{ fontSize: 12, letterSpacing: 1, color: '#222' }}>INTELLIGENCE AT THE EDGE</div>
          </div>

          <div style={{ textAlign: 'right', width: '100%', maxWidth: 560 }}>
            <StockTicker enabled={showTicker} onToggle={() => setShowTicker((v) => !v)} symbols={tickerSymbols} fetchViaProxy={fetchViaProxy} minimal />
          </div>
        </div>

        <div style={{ height: 1, background: '#ddd', margin: '14px 0' }} />

        <div style={{ fontWeight: 900, marginBottom: 10 }}>TOP STORY</div>
        {items.slice(0, 8).map((it) => (
          <LinkItem key={it.id} item={it} strong />
        ))}

        <div style={{ marginTop: 16, display: 'flex', gap: 10 }}>
          <button onClick={() => setMode((m) => (m === 'mock' ? 'rss' : 'mock'))} style={{ padding: '8px 10px', border: '1px solid #bbb', background: '#f7f7f7', cursor: 'pointer', fontWeight: 900 }}>
            {mode === 'mock' ? 'DATA: DEMO' : 'DATA: LIVE RSS'}
          </button>
          <button onClick={() => setViewMode((v) => (v === 'web' ? 'app' : 'web'))} style={{ padding: '8px 10px', border: '1px solid #111', background: '#111', color: '#fff', cursor: 'pointer', fontWeight: 900 }}>
            PREVIEW: {viewMode.toUpperCase()}
          </button>
        </div>

        <div style={{ marginTop: 10, fontSize: 12, color: '#666' }}>
          If you want the <b>full</b> feature-rich version (Flash expand/collapse, AI Pulse, Brink Brief, podcast module, settings sheet), tell me and I’ll drop it in as-is.
        </div>
      </div>
    </div>
  );
}

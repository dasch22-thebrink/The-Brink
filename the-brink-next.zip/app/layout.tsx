import "./globals.css";

export const metadata = {
  title: "The Brink — Intelligence at the Edge",
  description: "Newsflash on AI’s day-to-day growth: releases, research, business, policy, tools."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

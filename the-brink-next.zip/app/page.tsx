import TheBrinkNewsflash from "./the-brink";

export default function Page() {
  return <TheBrinkNewsflash />;
}
